export class Student{
	constructor(opt){
        this.name = opt.name;
        this.sex = opt.sex;
        this.age = opt.age;
    }

    getName() {
        return this.name;
    }

    setName(name) {
        this.name = name;
    }
}
