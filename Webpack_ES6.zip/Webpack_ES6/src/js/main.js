import {printInfor} from './zhangsan';

export {
    printInfor
}