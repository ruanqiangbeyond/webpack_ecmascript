import {Student} from './student';
const zhangsan =  new Student({
    name: 'zhangsan',
    sex: 'man',
    age: 30
});

function printInfor() {
    let info = '[name: ' + zhangsan.getName() + ' ,sex:' + zhangsan.sex + ' ,age: ' + zhangsan.age +']';
    console.log(info);
}

export {
    printInfor
}