const path = require('path');
const webpack = require('webpack');


var config = {
    entry: './src/js/main.js',
   /*  entry: {
        main: './src/js/main.js'
    }, */
    target: 'web',
    output: {
        path: path.resolve(__dirname, 'dist'),
        libraryTarget: 'var',//可有可无，默认为var
        library: 'LL'//将整个组件挂在全局的LL上，LL挂在window上，不然没法访问
    },
    plugins: [
        new webpack.BannerPlugin('This file is created by ruanqiang' +  new Date())
    ],
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /(node_modules)/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['env']
                    }
                }
            }
        ]
    }
};

module.exports = (env, argv) => {

    if (argv.mode === 'development') {
        config.devtool = 'source-map';
        config.output.filename = 'build-debug.js';
        // config.output.filename = '[name]-[hash].js';//name和hash为占位符，name为entry里面的值，hash为每次打包的随机数
    }

    if (argv.mode === 'production') {
        config.output.filename = 'build.js';
    }

    return config;
};