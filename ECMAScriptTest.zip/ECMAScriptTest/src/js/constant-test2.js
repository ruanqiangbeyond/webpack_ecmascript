import * as Constants from 'constant'

export function print() {
    console.log(Constants.A);
    console.log(Constants.B);
}