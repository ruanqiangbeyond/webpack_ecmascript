class People {
    constructor(opt) {
        this.name = opt.name;
        this.sex = opt.sex;
        this.age = opt.age;
    }

    eat() {
        if (this.age  > 5) {
            console.log('eat');
        }
        else {
            console.log('drinking');
        }
    }

    toString() {
        return '(' + this.name + ', ' + this.sex +  ',' + this.age + ')';
    }
}

export  default People;