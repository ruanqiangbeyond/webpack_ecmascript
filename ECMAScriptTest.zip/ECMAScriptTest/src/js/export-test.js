export let name = 'ruanqiang';//ok
//follow defined ok
let age = 19;
export {
    age
}

//follow defined ok
export {
    age as nianling
}

//ecmascript定义常量
export const NAME = 'jim';

export function doSomething() {
    //todo
}

export class People {
    constructor(opt) {
        this.name = opt.name;
        this.sex = opt.sex;
    }

    toString() {
        return '[name: ' + this.name + ', sex: ' + this.sex + ';';
    }
}

//y以下三种方式不正确
//直接输出1不行，1不是对外接口，必须将对外属性、方法、类放置在{}中，
// export 1;
//
// let hight = 1;
// export hight;