import People from './people'

class Student extends People{
    constructor(opt) {
        super(opt);
        this.banji = opt.banji;
    }

    toString() {
        let _superProperty = super.toString();
        return _superProperty + this.banji;
    }

    println(str) {
        if (str !== '' && str !== undefined) {
            console.log(str);
        }
        else {
            console.log(this.toString());
        }
    }
}

export {
    Student
}
