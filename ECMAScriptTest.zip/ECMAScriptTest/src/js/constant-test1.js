import {A, B} from './constant';

export function print() {
    console.log(A);
    console.log(B);
}