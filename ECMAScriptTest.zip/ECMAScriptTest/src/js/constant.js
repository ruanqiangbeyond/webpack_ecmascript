const A = 'A';

const B = 'B';

export {
    A,
    B
}