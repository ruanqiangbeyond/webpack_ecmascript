import * as Util from './js/util';
import People from './js/people';
import {Student} from './js/student';
import * as Constants from './js/constant';

export { Util, Constants};
export {People, Student}