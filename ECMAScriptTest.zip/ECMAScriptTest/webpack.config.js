var path = require('path');
module.exports = {
    entry:path.resolve(__dirname,'src/main.js'),
    output: {
        filename: 'bundle.js',
        path:path.resolve(__dirname,'build'),
        library:'ll'
    },
    mode: 'development',//production
    module:{
        rules:[
            {
                test:/(\.jsx|\.js)$/,
                use:{
                    loader:"babel-loader",
                    options:{
                        presets:[
                            "env"
                        ]
                    }
                },
                exclude:path.resolve(__dirname,"node_modules"),
                include:path.resolve(__dirname,"src")
            }
        ]
    }
};